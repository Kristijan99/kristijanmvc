namespace KristijanMVC.Controllers
{
    using System;
    using System.Data.Entity;
    using System.Linq;
    using KristijanMVC.Models;

    public class VehicleContext : DbContext
    {

        public VehicleContext() : base("name=VehicleContext")
        {
            Database.SetInitializer(new VehicleInitializer());
        }

        public DbSet<VehicleMake> VehicleMakes { get; set; }

        public DbSet<VehicleModel> VehicleModels { get; set; }
    }

}